// Problem#: 16921
// Submission#: 4297549
// The source code is licensed under Creative Commons Attribution-NonCommercial-ShareAlike 3.0 Unported License
// URI: http://creativecommons.org/licenses/by-nc-sa/3.0/
// All Copyright reserved by Informatic Lab of Sun Yat-sen University
#include<stdio.h>
int grade(float k) {
    if (k > 90) return 4;
    if (k > 80) return 3;
    if (k > 70) return 2;
    if (k > 60) return 1;
    return 0;
}
int main() {
    int i;
    float k;
    for (i = 1; i <= 5; ++i){
      scanf("%f", &k);
      printf("%d ", grade(k));
  }
  return 0;
}                                 
