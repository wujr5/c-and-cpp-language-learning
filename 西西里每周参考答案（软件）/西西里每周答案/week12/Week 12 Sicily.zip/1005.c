// Problem#: 16928
// Submission#: 4297729
// The source code is licensed under Creative Commons Attribution-NonCommercial-ShareAlike 3.0 Unported License
// URI: http://creativecommons.org/licenses/by-nc-sa/3.0/
// All Copyright reserved by Informatic Lab of Sun Yat-sen University
#include<stdlib.h>
int * count(const char * const s) {
    int i;
    int *p = (int*)malloc(10*sizeof(int));
    for (i = 0; i <= 9; ++i)
      *(p+i) = 0;
      i = 0;
    while (*(s+i) != '\0') {
        if (*(s+i) >= '0' && *(s+i) <= '9')
          ++*(p + *(s+i)-'0');
          ++i;
    }
            return p;
}                                 
