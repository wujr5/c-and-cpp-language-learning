// Problem#: 16929
// Submission#: 4297463
// The source code is licensed under Creative Commons Attribution-NonCommercial-ShareAlike 3.0 Unported License
// URI: http://creativecommons.org/licenses/by-nc-sa/3.0/
// All Copyright reserved by Informatic Lab of Sun Yat-sen University
int countLetters(const char * const str) {
    int i = 0, sum = 0;
    while (*(str+i) != '\0') {
        if ((*(str+i) >= 'A' && *(str+i) <= 'Z') || (*(str+i) >= 'a' && *(str+i) <= 'z')) ++sum;
          ++i;
    }
    return sum;
}                                 
