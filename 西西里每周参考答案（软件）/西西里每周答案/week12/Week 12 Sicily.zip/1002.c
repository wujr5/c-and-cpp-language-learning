// Problem#: 16925
// Submission#: 4297687
// The source code is licensed under Creative Commons Attribution-NonCommercial-ShareAlike 3.0 Unported License
// URI: http://creativecommons.org/licenses/by-nc-sa/3.0/
// All Copyright reserved by Informatic Lab of Sun Yat-sen University
#include<stdlib.h>
int * doubleCapacity(int *list, int size) {
    int i;
    int *newlist = (int *)malloc(2*size*sizeof(int));
    for (i = 0; i < 2*size; ++i)
      if ( i < size) *(newlist+i) = *(list+i); else *(newlist+i) = 0;
    return newlist;
}                                 
