// Problem#: 16924
// Submission#: 4296865
// The source code is licensed under Creative Commons Attribution-NonCommercial-ShareAlike 3.0 Unported License
// URI: http://creativecommons.org/licenses/by-nc-sa/3.0/
// All Copyright reserved by Informatic Lab of Sun Yat-sen University
#include<stdio.h>
float average(float a[], int n) {
    float sum = 0;
    int i;
    for (i = 1; i <= n; ++i)
      sum+= a[i];
    return (sum/n);
}
int above(float x, float a[], int n) {
    int i, count = 0;
    for (i = 1; i <= n; ++i)
      if (a[i] > x) ++count;
    return count;
}
int main() {
    float a[100], x;
    int i, n, t, j;
    scanf("%d", &t);
    for (j = 1; j <= t; ++j) {
    scanf("%d", &n);
    for (i = 1; i <= n; ++i)
      scanf("%f", &a[i]);
    x = average(a, n);
    printf("%d\n", above(x, a, n));
}
    return 0; 
}                                 
