// Problem#: 16927
// Submission#: 4297140
// The source code is licensed under Creative Commons Attribution-NonCommercial-ShareAlike 3.0 Unported License
// URI: http://creativecommons.org/licenses/by-nc-sa/3.0/
// All Copyright reserved by Informatic Lab of Sun Yat-sen University
int indexOf(const char *s1, const char *s2) {
    int i, j;
    for (i = 0; s2[i] != '\0'; ++i) {
        for (j = 0; s1[j] != '\0'; ++j)
          if (*(s2+i+j) != *(s1+j)) break;
        if (s1[j] == '\0') return i;
    }
    return -1;
}                                 
