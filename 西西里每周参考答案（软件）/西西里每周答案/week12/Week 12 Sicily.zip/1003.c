// Problem#: 16926
// Submission#: 4296949
// The source code is licensed under Creative Commons Attribution-NonCommercial-ShareAlike 3.0 Unported License
// URI: http://creativecommons.org/licenses/by-nc-sa/3.0/
// All Copyright reserved by Informatic Lab of Sun Yat-sen University
int smallestElement(int * array, int size) {
    int i, min = *array;
    for (i = 1; i < size; ++i)
      if (min > *(array+i)) min = *(array+i);
    return min;
}                                 
