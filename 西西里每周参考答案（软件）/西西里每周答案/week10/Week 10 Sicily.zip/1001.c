// Problem#: 16668
// Submission#: 4220413
// The source code is licensed under Creative Commons Attribution-NonCommercial-ShareAlike 3.0 Unported License
// URI: http://creativecommons.org/licenses/by-nc-sa/3.0/
// All Copyright reserved by Informatic Lab of Sun Yat-sen University
#include<stdio.h>
#include<string.h>
int main() {
    int m, n, i, j;
    char s[110];
    while (scanf("%d%d", &n, &m) != EOF) {
        for (i = 1; i <= n; ++i) {
          scanf("%s", s);
          for (j = strlen(s)-1; j >= 0; --j)
            if (s[j] != 'b') printf("%c", s[j]);
              else printf("d");
          printf("\n");
      }
      printf("\n");
    }
    return 0;
}                                 
