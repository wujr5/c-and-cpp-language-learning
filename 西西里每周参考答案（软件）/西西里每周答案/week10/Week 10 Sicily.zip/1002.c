// Problem#: 16669
// Submission#: 4220468
// The source code is licensed under Creative Commons Attribution-NonCommercial-ShareAlike 3.0 Unported License
// URI: http://creativecommons.org/licenses/by-nc-sa/3.0/
// All Copyright reserved by Informatic Lab of Sun Yat-sen University
#include<stdio.h>
#include<string.h>
int main() {
    char s[20];
    int a, b, i, k;
    while(scanf("%s", s) != EOF) {
        a = 0; b = 0; k = 0;
      while (s[k] >= '0' && s[k] <= '9') {
          a = 10*a + s[k] - '0';
          ++k;
      }
      for (i = k+1; i <= strlen(s)-1; ++i)
        b = 10*b + s[i] - '0';
      if (s[k] == '+') printf("%d\n", a+b);
      else
      printf("%d\n", a-b);
    }
    return 0;
}                                 
