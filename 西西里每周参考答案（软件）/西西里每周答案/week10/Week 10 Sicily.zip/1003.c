// Problem#: 16670
// Submission#: 4220649
// The source code is licensed under Creative Commons Attribution-NonCommercial-ShareAlike 3.0 Unported License
// URI: http://creativecommons.org/licenses/by-nc-sa/3.0/
// All Copyright reserved by Informatic Lab of Sun Yat-sen University
#include<stdio.h>
#include<string.h>
int top = 0;
struct str {
    char name[200];
};
struct str gift[110];
void put_gift(char s[]) {
    strcpy(gift[top].name, s);
    ++top;
}
void send_gift(char s[]) {
    --top;
    printf("%s %s\n", s, gift[top].name);
}
int main() {
    int n, i, j, k;
    char s[200];
    scanf("%d", &n);
    for (i = 1; i <= n; ++i) {
        scanf("%d", &k); getchar();
        scanf("%s", s);
        if (k == 1) put_gift(s);
        if (k == 2) send_gift(s);
    }
    return 0;
}                                 
