// Problem#: 16671
// Submission#: 4220692
// The source code is licensed under Creative Commons Attribution-NonCommercial-ShareAlike 3.0 Unported License
// URI: http://creativecommons.org/licenses/by-nc-sa/3.0/
// All Copyright reserved by Informatic Lab of Sun Yat-sen University
int sumDigits(unsigned int n) {
    int sum = 0;
    while (n > 0) {
        sum+= n%10;
        n/= 10; 
    }
    return sum;
}                                 
