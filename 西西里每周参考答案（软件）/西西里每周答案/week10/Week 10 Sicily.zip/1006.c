// Problem#: 16675
// Submission#: 4220940
// The source code is licensed under Creative Commons Attribution-NonCommercial-ShareAlike 3.0 Unported License
// URI: http://creativecommons.org/licenses/by-nc-sa/3.0/
// All Copyright reserved by Informatic Lab of Sun Yat-sen University
#include<stdio.h>
int multi(int a[], int d) {
    int k = 1, t[300], i;
    for (i = 1; i <= 300; ++i)
      t[i] = 0;
    while (k <= d) {
        t[k]+= a[k] * 3;
        t[k +1] = t[k]/10;
        t[k] = t[k] %10;
        k ++;
    }
    for (i = 1; i <= k; ++i)
      a[i] = t[i];
      return k;
}



int sum(int ans[], int a[]) {
    int t[300], k = 1, i;
    for (i = 1; i <= 300; ++i)
      t[i] = 0;
    while (a[k] != 0 || ans[k] != 0) {
        t[k]+= a[k] + ans[k];
        t[k+1] = t[k]/10;
        t[k] = t[k]%10;
        k++;
    }
    for (i = 1; i <= k; ++i)
      ans[i] = t[i];
      return k;
}



int main() {
    int ans[300], a[300], k, n, i, flag = 0;
    for (i = 1; i <= 300; ++i) {
        a[i] = 0;
        ans[i] = 0;
    }
    a[1] = 1; k = 1;
    scanf("%d", &n);
    for (i = 1; i <= n; ++i) {
        k = multi(a, k);
    }
    for(i = k; i>= 1; --i)
      if (flag == 0 && a[i] == 0) continue;
      else {
       printf("%d", a[i]);
       flag = 1;
   }
      printf("\n");
    return 0;
}                                 
