// Problem#: 16667
// Submission#: 4220356
// The source code is licensed under Creative Commons Attribution-NonCommercial-ShareAlike 3.0 Unported License
// URI: http://creativecommons.org/licenses/by-nc-sa/3.0/
// All Copyright reserved by Informatic Lab of Sun Yat-sen University
#include<stdio.h>
#include<string.h>
int main() {
    int k;
    char s[1001];
    while (scanf("%s", s) != EOF) {
        k = 0;
        while(k < strlen(s)) {
            printf("%c", s[k]);
            k+= 2;
        }
        printf(",");
        k = 1;
        while(k < strlen(s)) {
            printf("%c", s[k]);
            k+= 2;
        }
        printf("\n");
    }
    return 0;
}                                 
