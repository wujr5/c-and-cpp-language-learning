// Problem#: 16783
// Submission#: 4256543
// The source code is licensed under Creative Commons Attribution-NonCommercial-ShareAlike 3.0 Unported License
// URI: http://creativecommons.org/licenses/by-nc-sa/3.0/
// All Copyright reserved by Informatic Lab of Sun Yat-sen University
#include<stdio.h>
int a;
void add2() {
    a = a+2;
}
void minus1() {
    a = a-1;
}
int main() {
    scanf("%d", &a);
    add2();
    minus1();
    printf("%d", a);
    return 0;
}                                 
