// Problem#: 16781
// Submission#: 4265491
// The source code is licensed under Creative Commons Attribution-NonCommercial-ShareAlike 3.0 Unported License
// URI: http://creativecommons.org/licenses/by-nc-sa/3.0/
// All Copyright reserved by Informatic Lab of Sun Yat-sen University
#include<stdio.h>
int qsort(int a[], int l,int r)
{
    if(l>=r)return 0;
    int k=a[l],t,p1=l,p2=r;
    while(p1<p2)
    {
        while((p1<p2)&&(a[p2]>=k))--p2;
        a[p1]=a[p2];
        while((p1<p2)&&(a[p1]<=k))++p1;
        a[p2]=a[p1];
        
    }
    a[p1]=k;
    qsort(a, l, p1-1);qsort(a, p2+1, r);
}
int main()
{
    int n, i, j;
    int a[1000001];
    scanf("%d",&n);
    for(i=1;i<=n;++i)
      scanf("%d",&a[i]);
    qsort(a, 1, n);
    for(i=1;i<=n;++i)
      printf("%d\n",a[i]);
    return 0;  
 }                                 
