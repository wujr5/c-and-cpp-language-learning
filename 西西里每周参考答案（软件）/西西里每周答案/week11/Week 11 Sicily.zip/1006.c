// Problem#: 16776
// Submission#: 4256976
// The source code is licensed under Creative Commons Attribution-NonCommercial-ShareAlike 3.0 Unported License
// URI: http://creativecommons.org/licenses/by-nc-sa/3.0/
// All Copyright reserved by Informatic Lab of Sun Yat-sen University
#include<stdio.h>
void hanoi(int k, int source, int dest, int temp) {
    if (k == 1) printf("%d%d\n", source, dest);
    else {
        hanoi(k-1, source, temp, dest);
        hanoi(1, source, dest, temp);
        hanoi(k-1, temp, dest, source);
    }
    return ;
}
int main() {
    int n;
    scanf("%d", &n);
    hanoi(n, 1, 3, 2);
    return 0;
}                                 
