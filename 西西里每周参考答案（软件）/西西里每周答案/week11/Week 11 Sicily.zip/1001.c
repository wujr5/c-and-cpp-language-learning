// Problem#: 16784
// Submission#: 4260910
// The source code is licensed under Creative Commons Attribution-NonCommercial-ShareAlike 3.0 Unported License
// URI: http://creativecommons.org/licenses/by-nc-sa/3.0/
// All Copyright reserved by Informatic Lab of Sun Yat-sen University
#include<stdio.h>
int n, i, a[100];
int main() {
    while (1) {
        scanf("%d", &n);
        if (n == -1) break;
        a[0] = 0; a[1] = 2;
        for (i = 2; i <= n; ++i)
          a[i] = a[i-1] + a[i-2];
        printf("%d\n", a[n]); 
    }
    return 0;
}                                 
