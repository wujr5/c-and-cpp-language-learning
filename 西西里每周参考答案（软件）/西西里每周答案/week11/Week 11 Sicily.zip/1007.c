// Problem#: 16778
// Submission#: 4257340
// The source code is licensed under Creative Commons Attribution-NonCommercial-ShareAlike 3.0 Unported License
// URI: http://creativecommons.org/licenses/by-nc-sa/3.0/
// All Copyright reserved by Informatic Lab of Sun Yat-sen University
bool isSorted(const int list[], int size) {
    int i;
    for (i = 1; i < size; ++i)
      if (list[i] < list[i-1]) return false;
    return true;
}                                 
