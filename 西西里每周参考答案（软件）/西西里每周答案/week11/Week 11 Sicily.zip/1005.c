// Problem#: 16787
// Submission#: 4265081
// The source code is licensed under Creative Commons Attribution-NonCommercial-ShareAlike 3.0 Unported License
// URI: http://creativecommons.org/licenses/by-nc-sa/3.0/
// All Copyright reserved by Informatic Lab of Sun Yat-sen University
#include<stdio.h>
#include<string.h>
int search(char s[], int l, int r) {
    int i, k = 0;
    for (i = l; i <= r; ++i) {
        if (s[i] == '(') ++k;
        if (s[i] == ')') --k;
        if (s[i] == '+' || s[i] == '-' || s[i] == '*' || s[i] =='/')
          if (k == 0) return i;
    }
    printf("Error between %d : %c and %d : %c\n", l, s[l] , r, s[r]);
}
int merge_number(int a, int b, char x) {
    switch(x) {
        case '+' : return a + b;
        case '-' : return a - b;
        case '*' : return a * b;
        case '/' : return a / b;
        default : printf("Error for charactor: %c\n", x);
    }
}
int change(char s[], int l, int r) {
    int i, sum = 0;
    for (i = l; i <= r; ++i)
      sum = 10*sum + s[i] - '0';
    return sum;
}
int calculate(char s[], int left, int right) {
    int l = left, r = right, m;
    if (l > r) return 0;
    if (s[l] == '(') {
        m = search(s, l + 1, r - 1);
        return merge_number(calculate(s, l + 1, m - 1), calculate(s, m + 1, r - 1), s[m]);
    }
    return change(s, l, r);
}
int main() {
    char s[500];
    while (scanf("%s", s) != EOF ) {
        printf("%d\n", calculate(s, 0, strlen(s) - 1));
    }
    return 0;
}                                 
