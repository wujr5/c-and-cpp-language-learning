// Problem#: 16785
// Submission#: 4256780
// The source code is licensed under Creative Commons Attribution-NonCommercial-ShareAlike 3.0 Unported License
// URI: http://creativecommons.org/licenses/by-nc-sa/3.0/
// All Copyright reserved by Informatic Lab of Sun Yat-sen University
#include<stdio.h>
int main() {
    int n, k, a[200], t, i;
    a[1] = 0; a[2] = 1;
    scanf("%d", &t);
  for (i = 1; i <= t; ++i) {
    scanf("%d", &n);
     k = 2;
    while (1) {
        if (a[k] > n) {
            printf("0\n");
            break;
        }
        else
          if (a[k] == n) {
              printf("%d\n", k);
              break;
          }
        else {
            ++k;
            a[k] = a[k-1] +a[k-2];
        }
    }
}
    return 0;
}                                 
