// Problem#: 16780
// Submission#: 4257291
// The source code is licensed under Creative Commons Attribution-NonCommercial-ShareAlike 3.0 Unported License
// URI: http://creativecommons.org/licenses/by-nc-sa/3.0/
// All Copyright reserved by Informatic Lab of Sun Yat-sen University
#include<stdio.h>
#include<stdlib.h>
typedef struct node {
    int value;
    struct node *lchild, *rchild;
};
void tree(int n, struct node* root) {
    struct node *p1, *p2;
    int i;
    scanf("%d", &root->value);
    for (i = 1; i <= n - 1; ++i) {
        p2 = root;
        p1 = malloc(sizeof(struct node));
        p1->lchild = NULL;
        p1->rchild = NULL;
        scanf("%d", &p1->value); 
        while (1) {
            if (p1->value >= p2->value)
              if (p2->rchild == NULL) {
                p2->rchild = p1;
                break;
              }
              else
                p2 = p2->rchild;
            if (p1->value < p2->value)
              if (p2->lchild == NULL) {
                p2->lchild = p1;
                break;
              }
              else
                p2 = p2->lchild;
        }
    }
}
void travel(struct node *root) {
    if (root == NULL) return ;
    travel(root->lchild); 
    printf("%d\n", root->value);
    travel(root->rchild);
    return;
}
int main() {
    struct node *root;
    int n;
    scanf("%d", &n);
    root = malloc(sizeof(struct node));
    root->lchild = NULL;
    root->rchild = NULL;
    tree(n, root);
    travel(root);
    return 0;   
}                                 
