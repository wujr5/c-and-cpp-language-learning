// Problem#: 16786
// Submission#: 4256882
// The source code is licensed under Creative Commons Attribution-NonCommercial-ShareAlike 3.0 Unported License
// URI: http://creativecommons.org/licenses/by-nc-sa/3.0/
// All Copyright reserved by Informatic Lab of Sun Yat-sen University
#include<stdio.h>
int main() {
    int k;
    int n, a[20], t, i;
    while (scanf("%d", &n) != EOF) {
    k = 0;
    if (n < 0) t = n+65536;
    else t = n;
    for (i = 0; i <= 16; ++i)
      a[i] = 0;
    while (t > 0) {
        a[k] = t%2;
        t/= 2;
        ++k;
    }
    for (i = 15; i >= 0; --i)
      printf("%d",a[i]);
    printf("\n");
  }
    return 0;
}                                 
