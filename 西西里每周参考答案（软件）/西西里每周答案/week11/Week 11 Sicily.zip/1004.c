// Problem#: 16777
// Submission#: 4256928
// The source code is licensed under Creative Commons Attribution-NonCommercial-ShareAlike 3.0 Unported License
// URI: http://creativecommons.org/licenses/by-nc-sa/3.0/
// All Copyright reserved by Informatic Lab of Sun Yat-sen University
#include<stdio.h>
int gcd(int a, int b) {
  if (b == 0) return a;
  gcd(b, a%b);
}
int main() {
    int a, b;
    while (scanf("%d %d", &a, &b) != EOF) {
      printf("%d\n", gcd(a, b));
  }
  return 0;
}                                 
