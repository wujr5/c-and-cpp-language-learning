// Problem#: 16779
// Submission#: 4257261
// The source code is licensed under Creative Commons Attribution-NonCommercial-ShareAlike 3.0 Unported License
// URI: http://creativecommons.org/licenses/by-nc-sa/3.0/
// All Copyright reserved by Informatic Lab of Sun Yat-sen University
void merge(const int list1[], int size1, const int list2[], int size2, int list3[]) {
    int i = 0, j = 0, k = 0;
    while (i < size1 && j < size2) {
        while (i < size1 && list1[i] <= list2[j]) {
                list3[k] = list1[i];
                ++k;
                ++i;
        }
        while (j < size2 &&  list2[j] <= list1[i]) {
                list3[k] = list2[j];
                ++k;
                ++j;
        }   
    }
    if (i < size1)
      for (i; i < size1; ++i) {
          list3[k] = list1[i];
          ++k;
      }
      for (j; j < size2; ++j) {
          list3[k] = list2[j];
          ++k;
      }
}                                 
