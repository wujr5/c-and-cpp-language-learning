#include<stdio.h>
int main() {
    char s;
    scanf("%c", &s);
    printf("%c\n", s+32);
    return 0;
}                                 
