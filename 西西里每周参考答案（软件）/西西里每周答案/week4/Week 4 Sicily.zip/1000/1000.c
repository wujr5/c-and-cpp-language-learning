#include<stdio.h>
int main() {
    int n, k, i;
    scanf("%d",&n);
    for (i = 1;i <= n; ++i) {
      scanf("%d", &k);
      printf("%d\n",k);
    }
    return 0;
}                                 
