#include<stdio.h>
int main() {
    float k, ans;
    scanf("%f", &k);
    ans = k*0.305;
    printf("%.3f\n", ans);
    return 0;
}                                 
