#include<stdio.h>
int main() {
    long long a, b;
     long long c;
    scanf("%lld%lld", &a, &b);
    c = a*b;
    printf("%lld\n", c);
    return 0;
}                                 
