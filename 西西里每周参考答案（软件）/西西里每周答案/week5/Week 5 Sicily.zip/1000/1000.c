#include<stdio.h>
int main() {
    char s1, s2, s3;
    scanf("%c%c%c", &s1, &s2, &s3);
    printf("%c%c%c\n", s1-32, s2-32, s3-32);
    return 0;
}                                 
