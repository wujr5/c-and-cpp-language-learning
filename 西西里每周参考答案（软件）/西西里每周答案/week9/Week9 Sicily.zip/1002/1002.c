// Problem#: 16519
// Submission#: 4177439
// The source code is licensed under Creative Commons Attribution-NonCommercial-ShareAlike 3.0 Unported License
// URI: http://creativecommons.org/licenses/by-nc-sa/3.0/
// All Copyright reserved by Informatic Lab of Sun Yat-sen University
#include<stdio.h>
float max(float a, float b, float c) {
    if (a >= b && a >= c) return a;
    if (b >= a && b >= c) return b;
    if (c >= a && c >= b) return c;
}
int main() {
    float a[4][4];
    int i, j;
    for (i = 1; i <= 3; ++i)
      for (j = 1; j <= 3; ++j)
        scanf("%f", &a[i][j]);
    printf("%.1f %.1f ", max(a[1][1], a[2][2], a[3][3]), max(a[1][3], a[2][2], a[3][1]));  
    return 0;
}                                 
