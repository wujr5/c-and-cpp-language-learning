#include<stdio.h>
#include<math.h>
int main() {
    double a, b, c;
    int t, i;
    scanf("%d", &t);
    for (i = 1; i <= t; ++i) {
      scanf("%lf%lf%lf", &a, &b, &c);
      if (fabs(a + b - c) < 1e-10) printf("Yes\n");
      else printf("No\n");
  }
    return 0;
}
