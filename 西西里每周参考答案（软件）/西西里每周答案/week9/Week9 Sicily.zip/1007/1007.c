#include<stdio.h>
    int n, m;
int main() {
    int instruction, temp, i, flag = 1;
    int a[100010], x = 0;
    long long sum[100010];
    sum[1] = 0;
    scanf("%d%d", &n, &m);
    for (i = 1; i <= n; ++i) {
      scanf("%d", &a[i]);
      sum[i] = sum[i-1] + a[i];
  }
    for (i = 1; i <= m; ++i) {
        scanf("%d", &instruction);
        if (instruction == 1) {
            flag = -flag;
            x = -x;
        }
        else if (instruction == 2) {
            scanf("%d", &temp);
            x+= temp;
        }
        else if (instruction == 3) {
                long long l, r;
    long long count = 0;
    scanf("%lld%lld", &l, &r);
    count = flag*(sum[r]-sum[l-1]) + (r-l+1)*x;
               printf("%lld\n", count);
    }
}
    return 0;
}
