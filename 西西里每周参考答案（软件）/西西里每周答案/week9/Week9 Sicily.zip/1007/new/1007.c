#include<stdio.h>
    int n, m;
    long long sum(int a[], int flag, long x) {
    long long l, r, i, k;
    long long count = 0, temp;
    scanf("%lld%lld", &l, &r);
    if (flag%2 == 0) k = 1;
    else k = -1;
    for (i = l; i <= r; ++i)
      count+= a[i];
    count = k*count + (r-l+1)*x;
    return count;
}
int main() {
    int instruction, temp, i, flag = 0;
    int a[100010], x = 0;
    scanf("%d%d", &n, &m);
    for (i = 1; i <= n; ++i)
      scanf("%d", &a[i]);
    for (i = 1; i <= m; ++i) {
        scanf("%d", &instruction);
        if (instruction == 1) {
            ++flag;
            x = -x;
        }
        else if (instruction == 2) {
            scanf("%d", &temp);
            x+= temp;
        }
        else if (instruction == 3) printf("%lld\n", sum(a, flag, x));
    }
    return 0;
}
