#include<stdio.h>
    char a[201][201][201];
int main() {
    int n, m, i, x, y, z;
    scanf("%d%d", &n, &m);
    for (i = 1; i <= n; ++i) {
        scanf("%d%d%d", &x, &y, &z);
        a[x][y][z] = 1;
    }
    for (i = 1; i <= m; ++i) {
        scanf("%d%d%d", &x, &y, &z);
        if (a[x][y][z] == 1) printf("Yes\n");
        else printf("No\n");
    }
    return 0;
}
