#include<stdio.h>
int main() {
    int n, m;
    int num[100][100],check[100][100];
    int i, j, k, o;
    scanf("%d %d", &n, &m);
    for(i=0;i<n;i++) {
        for(j=0;j<3;j++) {
            scanf("%d", &num[i][j]);
        }
    }
    for(i=0;i<m;i++) {
        for(j=0;j<3;j++) {
            scanf("%d", &check[i][j]);
        }
    }
    for(i=0;i<m;i++) {
        for(j=0;j<n;j++) {
            if(check[i][0]==num[j][0]) {
                if(check[i][1]=num[j][1]) {
                    if(check[i][2]==num[j][2])printf("Yes\n");
                    else printf("No\n");continue;
                }
                else printf("No\n");continue;
            }
            else printf("No\n");continue;
        }
    }
}
