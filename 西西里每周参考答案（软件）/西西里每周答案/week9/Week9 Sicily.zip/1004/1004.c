#include<stdio.h>
int main() {
    int a[12][12], i, j, b[12][12], ans[12][12], n, k;
    while (scanf("%d", &n) != EOF) {
    for (i = 1; i <= n; ++i)
      for (j = 1; j <= n; ++j)
        ans[i][j] = 0;
        
    for (i = 1; i <= n; ++i)
      for (j = 1; j <= n; ++j)
        scanf("%d", &a[i][j]);

    for (i = 1; i <= n; ++i)
      for (j = 1; j <= n; ++j)
        scanf("%d", &b[i][j]);

    for (i = 1; i <= n; ++i)
      for (j = 1; j <= n; ++j)
        for (k = 1; k <= n; ++k)
          ans[i][j] += a[i][k]*b[k][j];

    for (i = 1; i <= n; ++i) {
      for (j = 1; j <= n; ++j)
        if (j == 1) printf("%d", ans[i][j]);
        else printf(" %d", ans[i][j]);
      printf("\n");
    }

    }
    return 0;
}
