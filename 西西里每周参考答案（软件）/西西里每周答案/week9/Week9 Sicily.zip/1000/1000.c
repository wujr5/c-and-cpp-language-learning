#include<stdio.h>
int main() {
    int n, i, j, k = 0, t, a[50][50];
    scanf("%d", &n);
    t = 1;
    for (i = 0; i <= n; ++i)
      for (j = 0; j <= n; ++j)
        a[i][j] = 0;
    i = 1; j = 1;
    while (1) {
        if (n%2 == 0 && k == n*n) break;
        if (n%2 == 1 && k == n*n-1) {
            a[n/2+1][n/2+1] = n*n;
            break;
        }
        for (j = t; j <= n-t; ++j) {
            ++k;
            a[i][j] = k;
            if (k == n*n) break;
        }
        for (i = t; i <= n-t; ++i) {
            ++k;
            a[i][j] = k;
            if (k == n*n) break;
        }
        for (j = n-t+1; j >= t+1; --j) {
            ++k;
            a[i][j] = k;
            if (k == n*n) break;
        }
        for (i = n-t+1; i >= t+1; --i) {
            ++k;
            a[i][j] = k;
            if (k == n*n) break;
        }
        ++t;
        i = t; j = t;
        }
    for (i = 1; i <= n; ++i) {
      for (j = 1; j <= n; ++j)
        if (j == 1) printf("%d", a[i][j]);
        else printf(" %d", a[i][j]);
      printf("\n");
    }
    return 0;
}
