// Problem#: 16520
// Submission#: 4177581
// The source code is licensed under Creative Commons Attribution-NonCommercial-ShareAlike 3.0 Unported License
// URI: http://creativecommons.org/licenses/by-nc-sa/3.0/
// All Copyright reserved by Informatic Lab of Sun Yat-sen University
#include<stdio.h>
int main() {
    int a[12][12], i, j, b[12][12], n;
    while (1) {
    scanf("%d", &n);
    if (n == 0) return 0;
    for (i = 1; i <= n; ++i)
      for (j = 1; j <= n; ++j)
        scanf("%d", &a[i][j]);
    for (i = 1; i <= n; ++i)
      for (j = 1; j <= n; ++j) {
        scanf("%d", &b[i][j]); 
        b[i][j]+= a[i][j];
    }
    for (i = 1; i <= n; ++i) {
      for (j = 1; j <= n; ++j)
        if (j == 1) printf("%d", b[i][j]); 
        else printf(" %d", b[i][j]);
      printf("\n");
    }
}
    return 0;
}                                 
