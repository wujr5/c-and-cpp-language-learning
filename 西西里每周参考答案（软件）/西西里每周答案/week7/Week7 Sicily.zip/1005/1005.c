#include<stdio.h>
void change(int a[], int k) {
    int i;
	for (i = 8; i >= 1; --i) {
		a[i] = k%2;
		k/=2;
	}	
}
void rev(int num[]) {
	int i;
	for (i = 1; i <= 8; ++i)
	  if (num[i] == 0) num[i] = 1;
	  else if (num[i] == 1) num[i] = 0;
}
void inc(int num[]) {
	int i = 8;
	while (num[i] == 1) {
        num[i] = 0;
		--i;		
	}
	num[i] = 1;
}
int main() {
	int a[10], n, i, j;
	scanf("%d", &n);
	if (n >= 0) change(a, n);
	else {
	n = abs(n);
	change(a, n);
	rev(a);
	inc(a);
}
	for (i = 1; i <= 8; ++i) printf("%d", a[i]);
	printf("\n");
	return 0;
}
