#include<stdio.h>
int main() {
	int t, i, n, a[100], j, k, l, flag;
	scanf("%d", &t);
	for (j = 1; j <= t; ++j) {
	scanf("%d", &n);
	for (i = 1; i <= n; ++i) {
		scanf("%d", &a[i]);
		if (i == 1) printf("%d", a[i]);
		else {
		flag = 1;
        for (l = 1; l < i; ++l)
          if (a[l] == a[i]) {flag = 0; break;}
        if (flag) printf(" %d", a[i]);
    }
	}
	    printf("\n");
}
    return 0;
} 
