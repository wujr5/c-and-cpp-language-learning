#include<stdio.h>
int main() {
	int i, j, n, a[11], t;
	for (i = 1; i <= 10; ++i)
	  scanf("%d", &a[i]);
	for (i = 1; i <= 10; ++i)
	  for (j = 1; j <= 10; ++j) {
	  	if (a[i] < a[j]) {
	  		t = a[i];
	  		a[i] = a[j];
	  		a[j] = t;
		  }
	  }
	for (i = 1; i <= 10; ++i) printf("%d ", a[i]);
	printf("\n");
	return 0;
}
