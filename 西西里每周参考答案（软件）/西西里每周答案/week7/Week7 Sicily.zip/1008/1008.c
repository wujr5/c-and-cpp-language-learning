#include<stdio.h>
int main() {
	int t, j, i, k, n, max = -100000, second = -100000, temp;
	scanf("%d", &t);
	for (j = 1; j <= t; ++j) {
	scanf("%d", &n);
	max = -100000; second = -100000;
	for (i = 1; i <= n; ++i) {
		scanf("%d", &k);
		if (k > max) { second = max; max = k;}
		else if (k > second) second = k;
	}
	printf("%d\n", second);
}
	return 0;
}
