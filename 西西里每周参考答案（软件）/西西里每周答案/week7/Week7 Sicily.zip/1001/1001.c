#include<stdio.h>
int main() {
	int i, n, a[100], k, j;
		for (j = 1; j <= 20; ++j) a[j] = 0;
	for (i = 1; i <= 20; ++i) {
	  scanf("%d", &k);
	  if (i == 1) { printf("%d", k); a[k] = 1;}
	  else if (a[k] == 0) { printf("  %d", k); a[k] = 1;}
}
	  printf("\n");
	  return 0;
}
