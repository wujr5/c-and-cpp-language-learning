#include<stdio.h>
void outmonth(int n) {
	switch (n) {
		case 1: printf("January ");break;
		case 2: printf("February ");break;
		case 3: printf("March ");break;
		case 4: printf("April ");break;
		case 5: printf("May ");break;
		case 6: printf("June ");break;
		case 7: printf("July ");break;
		case 8: printf("August ");break;
		case 9: printf("September ");break;
		case 10: printf("October ");break;
		case 11: printf("November ");break;
		case 12: printf("December ");break;
}
}
void outday(int n) {
	switch (n) {
		case 0: printf("Sunday\n"); break;
		case 1: printf("Monday\n"); break;
		case 2: printf("Tuesday\n"); break;
		case 3: printf("Wednesday\n"); break;
		case 4: printf("Thursday\n"); break;
		case 5: printf("Friday\n"); break;
		case 6: printf("Saturday\n"); break;
	}
}
int main() {
	int year, first, month, amount = 0, i;
	int num[13];
	num[1] = 31; num[2] = 28; num[3] = 31; num[4] = 30; num[5] = 31; num[6] = 30; num[7] = 31; num[8] = 31; num[9] = 30; num[10] = 31; num[11] = 30; num[12] = 31; 
    scanf("%d%d", &year, &first);
    if (year%400 == 0) num[2] = 29;
    else if (year%4 == 0 && year%100 != 0) num[2] = 29;
    amount = first;
    for (month = 1; month <= 12; ++month)
      {
    outmonth(month);
    printf("1, %d is ", year);
    outday(amount);
        amount = (amount+num[month])%7;
}
    return 0;
}
