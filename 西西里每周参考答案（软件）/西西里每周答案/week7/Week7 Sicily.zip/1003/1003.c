#include<stdio.h>
int main() {
	int t, i, j, n, k, a[12];
	scanf("%d", &t);
	for (j = 1; j <= t; ++j) {
		scanf("%d", &n);
		for (i = 0; i <= 9; ++i) a[i] = 0;
	    for (i = 1; i <= n; ++i) {
	    	scanf("%d", &k);
	    	++a[k];
		}
		for (i = 0; i <= 9; ++i) 
		  if (a[i] > 0) printf("%d %d\n", i, a[i]);
}
return 0;
}
