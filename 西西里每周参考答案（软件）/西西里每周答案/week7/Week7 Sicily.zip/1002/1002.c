#include<stdio.h>
#include<math.h>
int isprime(long n) {
	long i, j;
	char a[100000];
	a[1] = 0; a[2] = 1;
	if ((n > 2) && (n%2 == 0)) return 0;
	for (i = 3; i <= floor(sqrt(n)); ++i)
	  if (i%2 != 0) a[i] = 1;
	  else a[i] = 0;
	  
	for (i=3; i <= floor(sqrt(n)); ++i) {
	  if (a[i] == 1) 
	  if (n%i == 0) return 0;
	  else for (j = i*i; j*i <= floor(sqrt(n)); j+=i)
	         a[j] = 0;
	     }
  return 1;
	}
int main() {
	int k, n, i;
	scanf("%d", &n);
	printf("2"); k = 1; i = 3;
	while (k < n) {
		if (isprime(i)) { ++k; printf(" %d", i);}
		++i;
		}
		printf("\n");
		return 0;
	}

