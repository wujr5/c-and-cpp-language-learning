#include<stdio.h>
int sum(int k, int m) {
	int s = 0;
	while (k != 0) {
		s+= k%m;
		k/= m;
	}
	return s;
}
int main() {
	int i, n, k;
	for (i = 1000; i <= 9999; ++i) {
	  if (sum(i, 10) == sum(i, 12) && sum(i, 12) == sum(i, 16))	printf("%d\n", i);
	}

}
