#include <stdio.h>
#include <stdlib.h>
#include <fcntl.h>
 
int main() {
    int randomData = open("/dev/urandom", O_RDONLY); //打开随机文件
 
    unsigned int m;
    read(randomData, &m, sizeof(m));
	m = m%199999+1;
	printf("%d\n", m);
    close(randomData); //关闭随机文件
    return 0;
}
