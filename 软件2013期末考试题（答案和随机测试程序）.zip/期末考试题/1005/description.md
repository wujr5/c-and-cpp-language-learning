## Description:

Suppose there are five kinds of coins:  5 角、 1 角、 5 分、 2 分和 1 分. Now we want to give change to the customer with as few coins as possible. Write a program to compute how many coins do we need.

 

假定有 5 角、 1 角、 5 分、 2 分和 1 分共 5 种硬币，在 给顾客找硬币时，一般都会尽可能地选用硬币个数最小的方法。 例如，当要给某顾客找 7 角 2 分钱时，会给他一个 5 角， 2 个 1 角 和 1 个 2 分的硬币。试编写一个程序，输入的是要找给顾客的零 钱（以分为单位），输出的是应该找回的各种硬币数目，并保 证找回的硬币数最少。

 

## Input

A line contains the total amount (以分为单位)

For example:

101

 

## Output

Five lines that contain the number of  5 角、 1 角、 5 分、 2 分和 1 分 coins, respectively.

For example:

2

0

0

0

1

 


## Hint:

使用整除和取模操作。
