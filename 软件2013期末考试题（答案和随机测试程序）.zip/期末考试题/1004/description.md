## Description:

Remove all redudant chacacters in a string.

For example, the input string is "abacaeedabcdcd", the output will be "abced".

 

## Input

A string whose length is less than 100.

 

For example:

abacaeedabcdcd

 

## Output

The processed string which removes all redundant chacacters.

 

For example:

abced

 


## Hint:

Hint is not available for this exercise.
