#include <stdio.h>
#include <stdlib.h>
#include <string.h>
 
int main() {
    char a[100], b[100];
    int n, i, j, cnt = 1;
    gets(a);
    n = strlen(a);
    b[0] = a[0];
    for (i = 1; i < n; i++) {
        for (j = 0; j < i; j++) {
            if (a[i] == a[j])
                break;
        }
        if (a[i] == a[j] && i == j) {
            b[cnt]=a[i];
            cnt++;
        }
    }
    for (i = 0; i < cnt; i++)
        printf("%c", b[i]);
    printf("\n");
    return 0;
}
