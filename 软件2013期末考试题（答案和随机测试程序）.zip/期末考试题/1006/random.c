#include <stdio.h>
#include <stdlib.h>
#include <fcntl.h>
 
int main() {
    int randomData = open("/dev/urandom", O_RDONLY); //打开随机文件
 
    unsigned int m, a, i;
    read(randomData, &m, sizeof(m));
	m = m%100+1;
	for(i=0;i<m;i++) {
		read(randomData, &a, sizeof(a));
		a = a%23+'a';
		printf("%c", a);
	}
	printf("\n");
	close(randomData); //关闭随机文件
    return 0;
}
 
