## Description:

A string is called circle string if it is the same as its reverse. Now write a program to judge whether the string is a circle string.

正读和反读都相同的字符串称为回文。编写程序判断输入的字符串是否回文。

 

## Input

A string whose length is less than 100.

For example:

abcba

accba

 

## Output

"yes" if the input string is a circle string.

"no X" if the input string is not a circle string, and X is the first character that does not satisfy the circling condition (从左到右，第一个不满足回文条件的字符). 

 

For example:

"yes" (abcbc is a circling string)

"no c"  (accba is not a cicling string, and c is the first character that violates the circling condition).
