#include <stdio.h>
#include <string.h>
 
int main() {
    char str[200];
    int length;
 
    scanf("%s", str);
    length = strlen(str);
 
    int i;
    for (i = 0; i < length; i++) {
        if (str[i] != str[length-i-1]) {
            printf("no %c", str[i]);
            return 0;
        }
    }
    printf("yes");
    return 0;
}
