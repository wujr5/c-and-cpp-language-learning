#include <stdlib.h>
#include <stdio.h>
 
int main() {
    int current_fish;
    float decrease_ratio;
    scanf("%d %f", &current_fish, &decrease_ratio);
 
    float feature_fish, half_fish;
    int half_years, one_tenth_years;
    feature_fish = current_fish;
    one_tenth_years = 0;
    while (feature_fish > current_fish / 2) {
        feature_fish = feature_fish * (1 - decrease_ratio);
        one_tenth_years = one_tenth_years + 1;
    }
    half_years = one_tenth_years;
    half_fish = feature_fish;
    while (feature_fish > current_fish / 10) {
        feature_fish = feature_fish * (1 - decrease_ratio);
        one_tenth_years = one_tenth_years + 1;
    }
    printf("%d %d\n", half_years, one_tenth_years);
    return 0;
}
