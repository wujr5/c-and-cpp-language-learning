## Description:

Suppose there are X fishes in the pearl river currently, and the number of fishes decreases by Y every year. 

Please write a program to compute after how many years do the number of fishes decrease to half of their current number, and how many years do the number decrease to one tenth of the current number.

 

有关专家十分关注珠江渔业资源的问题。目前珠江中大约有X条鱼，平均每年以y％的速度减少。请编写一个程序，计算在多少年之后鱼的数目下降到目前的一半？多少年后下降到目前的十分之一？

 

## Input

A line that contains X and Y.

X is an integer between 1000 to 10000000, Y is a floating number between 0.01 to 1.0

 

For example:

```
800000 0.50
```
 

## Output

How many years will the fishes decease to half,  How many years will the fishes decease to one tenth

For example:

```
1 4
```

