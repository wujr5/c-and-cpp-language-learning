#include <stdio.h>
#include <stdlib.h>
#include <fcntl.h>
 
int main() {
    int randomData = open("/dev/urandom", O_RDONLY);
    unsigned int n1, n2;
    read(randomData, &n1, sizeof(n1));
    read(randomData, &n2, sizeof(n2));
    n2 = n2%99+1;
    
    printf("%d %f\n", 1000 + n1%(10000000-1000), ((float)n2)/100+0.001);
    close(randomData);
    return 0;
}
