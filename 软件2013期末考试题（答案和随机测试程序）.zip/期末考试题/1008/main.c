#include <stdio.h>
int n, m, t, a[100][100], i, j, ans;
int main() {
    int x1, y1, x2, y2, c, colors[21];
    scanf("%d%d%d", &n, &m, &t);
    for (i = 0; i < n; i++)
    for (j = 0; j < n; j++) a[i][j] = 0;
    while (t--) {
        scanf("%d%d%d%d%d", &x1, &y1, &x2, &y2, &c);
        for (i = x1; i <= x2; i++)
        for (j = y1; j <= y2; j++)
        a[i - 1][j - 1] = c;
    }
    for (i = 0; i <= 20; i++) colors[i] = 0;
    for (i = 0; i < n; i++)
    for (j = 0; j < m; j++)
    colors[a[i][j]] = 1;
    ans = 0;
    for (i = 0; i <= 20; i++) ans += colors[i];
    printf("%d", ans);
    return 0;
}
