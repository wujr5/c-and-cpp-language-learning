## Description

Ziyao has a big drawing board with N * M squares. At the beginning, all the squares on the board are white, represented by the number 0. We can see the 4 * 4 whilte drawing board is:

0000

0000

0000

0000



One day Ziyao wants to draw on the board. He will draw  for T times. Each time he will draw a rectangle with the color he like.For each rectangle, we use 4 integers (x1, y1, x2, y2) to express it. It means all squares whose coordinate (x, y)  exist both x1 <= x <=x2 and y1 <= y <= y2. If two rectangles are intersected， the intersected part will be covered by the color later drawing.

 For example, if he draw a rectangle (1, 2, 3, 3) on the white board with the color ‘1’, the board will be:



0110

0110

0110

0000



And if he go on drawing a rectangle (2, 1, 3, 2) by ‘2’, the board will be:



0110

2210

2210

0000



Now, Ziyao Big God will tell you his drawing process, please tell me how many colors will be there on the board.



## Input



The first line has 3 integers, N, M, T.(0 < N, M <= 100, 0 <= T <=20)

The next T lines, each line has 5 integers x1, y1, x2, y2, c, (x1, y1, x2, y2) express the rectangle and c is the color.(1 <= x1, x2 <= N, 1 <= y1, y2 <=M, 1 <= c <= T)



## Output



Just one number, how many colors on the board.

PS:’0’ is also a kind of color.



Sample Input 1



4 4 2

1 2 2 3 1

2 1 3 2 2



Sample Input 2



4 4 2

1 1 1 1 2

1 1 4 4 1



Sample Output 1



3



Sample Output 2



1




## Hint:

For the first sample, the board is

0110

2210

2200

0000

There are 3 colors:0,1,2.



For the second sample, the board is

1111

1111

1111

1111

There are only 1 color: 1.
