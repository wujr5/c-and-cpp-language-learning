    #include <stdio.h>
#include <stdlib.h>
#include <fcntl.h>
 
int main() {
    int randomData = open("/dev/urandom", O_RDONLY); 
 
    unsigned int n, m, t, x1, x2, y1, y2, c, i;
    read(randomData, &n, sizeof(n));
    read(randomData, &m, sizeof(m));
    read(randomData, &t, sizeof(t));
    n = n % 100 + 1;
    m = m % 100 + 1;
    t = t % 21;
    printf("%d %d %d\n", n, m, t);
    i = t;
    while (i--) {
        x2 = rand() % n;
        x1 = rand() % (x2 + 1);
        y2 = rand() % m;
        y1 = rand() % (y2 + 1);
        c = rand() % t + 1;
        printf("%d %d %d %d %d\n", x1 + 1, y1 + 1, x2 + 1, y2 + 1, c);
    }
	close(randomData);
    return 0;
}
