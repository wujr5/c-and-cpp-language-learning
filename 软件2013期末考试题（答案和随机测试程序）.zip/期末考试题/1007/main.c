#include <stdlib.h>
#include <stdio.h>
int main() {
    int number, temp_number;
    int factor_count;
    int base;
    scanf("%d %d", &number, &base);
    factor_count = 0;
    temp_number = number;
    while (temp_number % base == 0) {
        factor_count = factor_count + 1;
        temp_number = temp_number / base;
    }
    printf("%d\n", factor_count);
    return 0;
}
