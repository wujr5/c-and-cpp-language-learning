Write a program to find out how many factor a number contains.

编写一个程序，求一个自然数number中含有多少个base的因子。

 

## Input

A line that contains the number (10<number≤10000) and the base (2≤base≤10).

For example:

12 2

 

 

## Output

The number of factors.

For example:

2
