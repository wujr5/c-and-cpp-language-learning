#include <stdio.h>
#include <stdlib.h>
#include <fcntl.h>
#include <unistd.h>
 
int main(void) {
    int randomData = open("/dev/urandom", O_RDONLY);
    unsigned int number, base;
    read(randomData, &number, sizeof(number));
    read(randomData, &base, sizeof(base));
    printf("%d %d\n", number%9000+100, base%9+2);
    close(randomData);
    return 0;
}
