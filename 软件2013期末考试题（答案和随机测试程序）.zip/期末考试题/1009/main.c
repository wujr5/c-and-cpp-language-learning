#include <stdio.h>
#include <string.h>
char box[6][7] = {
    "..+---+",
    "./   /|",
    "+---+ |",
    "|   | +",
    "|   |/.",
    "+---+.."};
char map[1000][1000];
int main() {
    int n, m, hig, wid, i, j, k, a[50][50], x, y, p, q;
    while (scanf("%d %d", &n, &m) != EOF) {
        hig = 0; wid = 0;
        for (i = 0; i < 1000; i++)
        for (j = 0; j < 1000; j++) map[i][j] = '.';
        for (i = 0; i < n; i++)
        for (j = 0; j < m; j++) {
            scanf("%d", &a[i][j]);
            for (k = 0; k < a[i][j]; k++) {
                x = (n - 1 - i) * 2 + k * 3;
                y = j * 4 + (n - 1 - i) * 2;
                if (x + 6 > hig) hig = x + 6;
                if (y + 7 > wid) wid = y + 7;
                for (p = 0; p < 6; p++)
                for (q = 0; q < 7; q++)
                if (box[5 - p][q] != '.')
                    map[x + p][y + q] = box[5 - p][q];
            }
        }
        for (i = hig - 1; i >= 0; i--) {
            for (j = 0; j < wid; j++) putchar(map[i][j]);
            puts("");
        }
    }
    return 0;
}
