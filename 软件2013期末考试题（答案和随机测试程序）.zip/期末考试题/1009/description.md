Description:

Constraints

Time Limit: 1 secs, Memory Limit: 32 MB

Description

Ziyao is a smart boy. He often tell his little friends something what he interested in. Now，he is prepared to tell about stereo diagram(立体图). You should help him to draw the diagram, or fail the class.

Ziyao has a rectangular region, and its area is n * m. There are n * m square of side length 1. There are some the same size blocks on each square. Each blocks are all the same and their length and width and height are 1. Ziyao wants you to print out the stereo diagram of these blocks.We define each building block for the following format, and not do any reversal rotation, only strictly to this form of display:


```
  +---+
 /   /|  height
+---+ |
|   | +
|   |/ width
+---+
 Length
```
Each point express by a ‘+’, length express by three ‘-’ width express by a ‘/’，and height express by two ‘|’。And we use the character ’.’ as the background .It means the blank part of stereo pictures need to instead by ‘.’ . Stereo diagram drawing as the following rules:

If two adjacent blocks left and right, it will be:
```
..+---+---+

./   /   /|

+---+---+ |

|   |   | +

|   |   |/.

+---+---+..
```
If two adjacent blocks up and down, it will be:
```
..+---+

./   /|

+---+ |

|   | +

|   |/|

+---+ |

|   | +

|   |/.

+---+..
```
If two adjacent blocks front and behind, it will be:
```
....+---+

.../   /|

..+---+ |

./   /| +

+---+ |/.

|   | +..

|   |/...

+---+....
```
Input

The first line has two integer m and n, which means there are m*n squares（1<=m，n<=20）.

The next n lines，each line has n integers, the integer in the i line j column means how many blocks there are on the (i,j) square. All the integers is less than 100.



Output

Print the diagraph. It is a K-line L-column characters’ square, while K and L means you need at least K lines ans L columns two print it.



Sample Input 1

3 4

2 2 1 2

2 2 1 1

3 2 1 2

Sample Input 2

2 2

0 1

2 0





Sample Output 1
```
......+---+---+...+---+

..+---+  /   /|../   /|

./   /|-+---+ |.+---+ |

+---+ |/   /| +-|   | +

|   | +---+ |/+---+ |/|

|   |/   /| +/   /|-+ |

+---+---+ |/+---+ |/| +

|   |   | +-|   | + |/.

|   |   |/  |   |/| +..

+---+---+---+---+ |/...

|   |   |   |   | +....

|   |   |   |   |/.....

+---+---+---+---+......
```


Sample Output 2
```
..+---+......

./   /|.+---+

+---+ |/   /|

|   | +---+ |

|   |/|   | +

+---+ |   |/.

|   | +---+..

|   |/.......

+---+........
```
