#include <stdio.h>
#include <stdlib.h>
#include <fcntl.h>
 
int main() {
    int randomData = open("/dev/urandom", O_RDONLY);
    int n = 20, m = 20, i, j, k;
    unsigned int x;
    printf("%d %d\n", n, m);
    for (i = 0; i < n; i++) {
        read(randomData, &x, sizeof(x));
        for (j = 0; j < n; j++) printf("%d ", x % 100 + 1);
        puts("");
    }
    close(randomData);
    return 0;
}
