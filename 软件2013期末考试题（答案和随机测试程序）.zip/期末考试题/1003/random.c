#include <stdio.h>
#include <stdlib.h>
#include <fcntl.h>
#include <unistd.h>
 
int main(void) {
    int randomData = open("/dev/urandom", O_RDONLY);
    unsigned int len1, len2;
    read(randomData, &len1, sizeof(len1));
    read(randomData, &len2, sizeof(len2));
    
    len1 = len1%20;
    len2 = len2%20;
    
    int i;
    unsigned int e;
    
    printf("%d\n", len1);
    for(i=0;i<len1;i++){
        read(randomData, &e, sizeof(e));
        e=e%20;
        printf("%d\n", e);
    }
    
    printf("%d\n", len2);
    for(i=0;i<len2;i++){
        read(randomData, &e, sizeof(e));
        e=e%20;
        printf("%d\n", e);
    }
        
    close(randomData);
    return 0;
}
