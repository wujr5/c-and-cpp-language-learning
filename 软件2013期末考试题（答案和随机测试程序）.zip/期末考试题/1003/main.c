#include <stdio.h>
#include <stdlib.h>
 
int main() {
     int len1, len2;
     int a1[100];
     int a2[100];
     int i;
     scanf("%d", &len1);
     for (i = 0; i < len1; i++) {
         scanf("%d", &(a1[i]));
     }
     scanf("%d", &len2);
     for (i = 0; i < len2; i++) {
         scanf("%d", &(a2[i]));
     }
     int count = 0;
     for ( ; len1 > 0 && len2 > 0; len1--, len2--) {
        if (a1[len1-1] != a2[len2-1]) {
             count++;
        }
     }
     printf("%d\n", count);
}
 
