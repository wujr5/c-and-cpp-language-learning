#include <stdio.h>
#include <stdlib.h>
#include <fcntl.h>
 
int main() {
    int randomData = open("/dev/urandom", O_RDONLY); //打开随机文件
    int j;
    unsigned int i, r;
	read(randomData, &i, sizeof(i));
	i=i%10+1;
    printf("%d\n", i);
	for (j=0;j<i;j++){
		read(randomData, &r, sizeof(r));
        r = r%3000 + 1;
		printf("%d\n", r);
	}
    close(randomData); //关闭随机文件
    return 0;
}
