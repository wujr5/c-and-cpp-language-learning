#include <stdio.h>
 
int main() {
    long r, area;
    int n;
    scanf("%d", &n);
    while (n--) {
        scanf("%d", &r);
        area = r * r;
        printf("%d\n", area);
    }
}
