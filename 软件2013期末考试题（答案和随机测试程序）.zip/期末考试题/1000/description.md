
## Description:

Given the size r of a square(正方形), calculate its area. 
Note that 0 < r ≤ 3000.

 

## [Input]

The fisrt line is an integer n between 1 and 10;

The following n lines contains n integer numbers between 0 and 3000.

  

## [Output]

Output the area of the square in each input line. 

 

[Sample Input]

```
3
1
2
3
```

[Sample Output]

```
1
4
9
```
 


Hint:

Hint is not available for this exercise.