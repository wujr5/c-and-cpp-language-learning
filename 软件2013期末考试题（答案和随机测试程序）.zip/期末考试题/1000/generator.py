import json
import os
import subprocess

class generator():
    proInput = []
    proOutput = []
    score = []

    def __init__(self):
        pass

    def generate(self, score, inputProgramm1, inputProgramm2):
        result = []
        os.system("gcc %s -o random" % str(inputProgramm1))
        os.system("gcc %s -o main" % str(inputProgramm2))
        for i in range(len(score)):
            self.getInput()
            self.getOutput()
            result.append({})
            result[i]["id"] = str(i + 1) 
            result[i]["input"] = self.proInput[i]
            result[i]["output"] = self.proOutput[i]
            result[i]["score"] = score[i]
        result = json.dumps(result, indent=4)
        f = open("data.json", "w")
        f.write(result)
        f.close()

    def getInput(self):
        a = subprocess.Popen("./random", shell=True, stdout=subprocess.PIPE)
        self.proInput.append(a.communicate()[0]);

    def getOutput(self):
        f = open("temp.txt", "w")
        f.write(str(self.proInput[-1]))
        f.close()
        f = file("temp.txt")
        a = subprocess.Popen("./main", shell=True, stdout=subprocess.PIPE, stdin=f)
        self.proOutput.append(a.communicate()[0])
        


if __name__ == "__main__":
    g = generator()
    g.generate([2 for i in range(50)], "random.c", "main.c")

