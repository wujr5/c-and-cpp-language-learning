#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
 
int main(void) {
    int randomData = open("/dev/urandom", O_RDONLY);
    unsigned int n1;
    read(randomData, &n1, sizeof(n1));
    printf("%d\n", n1%100000);
    close(randomData);
    return 0;
}
