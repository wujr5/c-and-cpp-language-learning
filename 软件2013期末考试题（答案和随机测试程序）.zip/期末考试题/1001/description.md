## Description:

Given an integer n, find the maximal integer x that satisfies 2x≤n.

(求不超过正整数n的2的最大幂值。)

 
## Input

The integer n (1≤n≤100000)

For example:

```
9
```
 

## Output

The maximum power 2x.

For example:

```
8
```

## Hint:

Hint is not available for this exercise.